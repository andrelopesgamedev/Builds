using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Clothing", menuName = "ScriptableObjects/Create Clothing", order = 1)]
public class Clothing : ScriptableObject
{
    public enum ClothingType
    {
        Hat,
        Outfit,
        Hairstyle,
        Underwear
    }
    public ClothingType clothingType;
    public string Name;
    public Sprite Image;
    public int Price;
}
