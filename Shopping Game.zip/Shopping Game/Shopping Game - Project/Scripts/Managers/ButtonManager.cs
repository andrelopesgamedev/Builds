using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonManager : MonoBehaviour
{
    InventorySlot ItemSlot;
    [SerializeField] PlayerInvetory Invetory;
    [SerializeField] GameObject ShopUI;
    public Clothing Item;
    public GameObject WannaBuyWindow;
    public GameObject WannaEquipWindow;
    public GameObject WannaSellWindow;
    public GameObject AlreadyHasItemWindow;
    public bool ShowShop;

    #region Singleton
    public static ButtonManager instance;
    private void Awake()
    {    
        if (instance != null)
        {
            Destroy(gameObject);
        }
        else
        {
            instance = this;
        }
    }
    #endregion

    private void Update()
    {
        OpenShop();
    }

    public void WannaBuyYesButton()
    {
        Invetory.AddItem(Item);
        WannaBuyWindow.SetActive(false);
    }

    public void WannaBuyNoButton()
    {
        WannaBuyWindow.SetActive(false);
    }

    public void WannaEquipYesButton()
    {
        Invetory.EquipItem(Item);
        WannaEquipWindow.SetActive(false);
    }

    public void WannaEquipNoButton()
    {
        WannaEquipWindow.SetActive(false);
    }

    public void WannaSellYesButton()
    {
        Invetory.RemoveItem(Item);
        WannaSellWindow.SetActive(false);
    }

    public void WannaSellNoButton()
    {
        WannaSellWindow.SetActive(false);
    }

    public void AlreadyHasItemWindowOkButton()
    {
        AlreadyHasItemWindow.SetActive(false);
    }

    public void OpenShop()
    {
        if (ShowShop)
        {
            ShopUI.SetActive(true);
        }
        else
        {
            ShopUI.SetActive(false);
        }
    }

    public void AppQuit()
    {
        Application.Quit();
    }
}
