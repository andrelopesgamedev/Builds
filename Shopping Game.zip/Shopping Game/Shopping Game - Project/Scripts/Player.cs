using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    #region Singleton
    public static Player instance;
    private void Awake()
    {
        if (instance != null)
        {
            Destroy(gameObject);
        }
        else
        {
            instance = this;
        }

    }
    #endregion

    #region Variables
    [SerializeField] ButtonManager btm;
    [SerializeField] float speed;
    [SerializeField] Animator anim;
    [SerializeField] UIManager ui;
    ShopKeeper shop;
    public bool ShowInventory;
    #endregion

    void Start()
    {
        anim = transform.GetComponent<Animator>();
        ui = UIManager.instance;
    }

    void Update()
    {
        Movement();
        ToggleInventory();

        if (Input.GetKeyDown(KeyCode.F) && shop.isInShopRange)
        {
            if (btm.ShowShop)
            {
                btm.ShowShop = false;
            }
            else
            {
                btm.ShowShop = true;
            }
        }
    }

    void Movement()
    {
        float x = Input.GetAxisRaw("Horizontal");
        float y = Input.GetAxisRaw("Vertical");

        transform.Translate(new Vector3(x, y, 0).normalized * speed * Time.deltaTime);

        anim.SetFloat("Walking X", x);
        anim.SetFloat("Walking Y", y);

        if (x != 0f || y != 0f)
        {
            anim.SetBool("isMoving", true);
        }
        else
        {
            anim.SetBool("isMoving", false);
        }
    }

    void ToggleInventory()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            if (ShowInventory)
            {
                ShowInventory = false;
            }
            else
            {
                ShowInventory = true;
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "Shop")
        {
            shop = collision.gameObject.GetComponent<ShopKeeper>();
        }
    }
}