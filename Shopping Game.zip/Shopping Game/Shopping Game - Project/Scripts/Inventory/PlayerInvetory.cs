using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerInvetory : MonoBehaviour
{
    int InventoryMaxCap = 8;
    public List<Clothing> CurrentItems = new List<Clothing>();
    public bool HasCurrentItem;
    [SerializeField] List<GameObject> allSlots = new List<GameObject>();
    [SerializeField] List<GameObject> SellSlots = new List<GameObject>();
    [SerializeField] List<GameObject> EquipableItems = new List<GameObject>();
    [SerializeField] GameObject InventoryUI;
    [SerializeField] GameObject SellShopUI;
    [SerializeField] RectTransform SlotsParent;
    [SerializeField] Player player;
    [SerializeField] ButtonManager btm;
    [SerializeField] SpriteRenderer HairOffSet;
    [SerializeField] SpriteRenderer UnderwearOffSet;
    [SerializeField] SpriteRenderer OutfitOffSet;
    [SerializeField] SpriteRenderer HatOffSet;
    [SerializeField] UIManager ui;
    public int Coins = 1000;

    #region Sigleton
    public static PlayerInvetory instance;

    private void Awake()
    {
        if (instance != null)
        {
            Destroy(gameObject);
        }
        else
        {
            instance = this;
        }

        btm = ButtonManager.instance;
    }
    #endregion

    private void Update()
    {
        ui.UpdateCoinUIText();

        if(InventoryUI.activeSelf)
            UpdateInvetoryUI();

        if (SellShopUI.activeSelf)
            UpdateSellShopUI();

        if (player.ShowInventory)
        {
            InventoryUI.SetActive(true);
        }
        else
        {
            InventoryUI.SetActive(false);
        }
    }

    public void AddItem(Clothing Item)
    {
        CurrentItems.Add(Item);
        Coins -= Item.Price;
        Debug.Log(Item.name + "Added to Inventory");
    }

    public void RemoveItem(Clothing Item)
    {
        CurrentItems.Remove(Item);
        Coins += Item.Price / 2;
        Debug.Log(Item.name + "Sold");
    }

    public void EquipItem(Clothing CurrentItemSlected)
    {
        if(CurrentItemSlected.clothingType == Clothing.ClothingType.Hat)
        {
            HatOffSet.sprite = CurrentItemSlected.Image;
        }
        if(CurrentItemSlected.clothingType == Clothing.ClothingType.Outfit)
        {
            OutfitOffSet.sprite = CurrentItemSlected.Image;
        }
        if(CurrentItemSlected.clothingType == Clothing.ClothingType.Hairstyle)
        {
            HairOffSet.sprite = CurrentItemSlected.Image;
        }
        if(CurrentItemSlected.clothingType == Clothing.ClothingType.Underwear)
        {
            UnderwearOffSet.sprite = CurrentItemSlected.Image;
        }
    }

    void UpdateInvetoryUI()
    {
        int tempIndexOfClothing = 0;

        for (int i = 0; i < 8; i++)
        {
            InventorySlot tempSlot = allSlots[i].GetComponent<InventorySlot>();

            if (tempIndexOfClothing < CurrentItems.Count)
                tempSlot.AddItem(CurrentItems[tempIndexOfClothing]);
            else
            {
                tempSlot.AddItem(null);
            }

            tempIndexOfClothing++;
        }
    }

    void UpdateSellShopUI()
    {
        int tempIndexOfClothing = 0;

        for (int i = 0; i < 8; i++)
        {
            InventorySlot tempSlot = SellSlots[i].GetComponent<InventorySlot>();

            if (tempIndexOfClothing < CurrentItems.Count)
                tempSlot.AddItem(CurrentItems[tempIndexOfClothing]);
            else
            {
                tempSlot.AddItem(null);
            }
            
            tempIndexOfClothing++;
        }
    }
}