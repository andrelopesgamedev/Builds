using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIManager : MonoBehaviour
{
    [SerializeField] GameObject PressFText;
    [SerializeField] TextMeshProUGUI CoinCount;
    [SerializeField] PlayerInvetory invetory;

    #region Singleton
    public static UIManager instance;

    private void Awake()
    {
        if (instance != null)
        {
            Destroy(gameObject);
        }
        else
        {
            instance = this;
        }
    }
    #endregion

    public void TogglePressFText()
    {
        if (PressFText.activeSelf == true)
        {
            PressFText.SetActive(false);
        }
        else
        {
            PressFText.SetActive(true);
        }
    }

    public void UpdateCoinUIText()
    {
        CoinCount.text = invetory.Coins.ToString();
    }
}
