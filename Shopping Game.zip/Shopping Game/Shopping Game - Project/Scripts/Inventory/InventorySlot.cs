using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class InventorySlot : MonoBehaviour
{
    public Clothing Item;

    [SerializeField] ButtonManager buttonManager;
    [SerializeField] PlayerInvetory Invetory;
    [SerializeField] Image ItemImage;
    [SerializeField] GameObject Child;
    [SerializeField] GameObject Shop;
    [SerializeField] TextMeshProUGUI CoinText;

    public void AddItem(Clothing NewItem)
    {
        ItemImage = Child.GetComponentInChildren<Image>();

        if(NewItem != null)
        {
            Item = NewItem;

            ItemImage.sprite = Item.Image;
        }
        else
        {
            Item = null;

            ItemImage.sprite = null;
        }

        if (Shop)
        {
            if (Shop.name == "Buy")
            {
                CoinText.text = Item.Price + "Coins";
            }
            else
            {
                CoinText.text = Item.Price / 2 + "Coins";
            }
        }
    }

    private void Start()
    {
        if (Shop)
        {
            if (Shop.name == "Buy")
            {
                AddItem(Item);
            }
        }
    }

    public void OnClickItemInShop()
    {
        buttonManager.Item = this.Item;
        ItemVerification();

        if (Invetory.HasCurrentItem)
        {
            buttonManager.AlreadyHasItemWindow.SetActive(true);
        }
        else
        {
            buttonManager.WannaBuyWindow.SetActive(true);
        }
    }

    public void OnClickItemInInventory()
    {
        buttonManager.Item = this.Item;

        buttonManager.WannaEquipWindow.SetActive(true);
    }

    public void OnClickItemInSellShop()
    {
        buttonManager.Item = this.Item;

        buttonManager.WannaSellWindow.SetActive(true);
    }

    public void ItemVerification()
    {
        if (Invetory.CurrentItems.Contains(Item))
        {
            Invetory.HasCurrentItem = true;
        }
        else
        {
            Invetory.HasCurrentItem = false;
        }
    }
}
