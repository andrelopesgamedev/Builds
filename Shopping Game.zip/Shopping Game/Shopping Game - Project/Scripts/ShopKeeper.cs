using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ShopKeeper : MonoBehaviour
{
    [SerializeField] UIManager ui;
    [SerializeField] ButtonManager btm;
    [SerializeField] GameObject HelloBallon;
    [SerializeField] GameObject GoodbyeBallon;

    float TextTimer = 6f;
    public bool isInShopRange;

    private void Update()
    {
        TextTimer -= Time.deltaTime;

        if(TextTimer <= 0)
        {
            HelloBallon.SetActive(false);
            GoodbyeBallon.SetActive(false);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            isInShopRange = true;
            TextTimer = 6f;
            HelloBallon.SetActive(true);
            GoodbyeBallon.SetActive(false);
            ui.TogglePressFText();
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            isInShopRange = false;
            btm.ShowShop = false;
            TextTimer = 6f;
            HelloBallon.SetActive(false);
            GoodbyeBallon.SetActive(true);
            ui.TogglePressFText();
        }
    }
}
